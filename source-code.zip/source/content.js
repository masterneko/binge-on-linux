localStorage.setItem('ares-can-use-high-drm','{ "value":true }');

